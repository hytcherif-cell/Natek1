
  # Natek Communication App Design

  This is a code bundle for Natek Communication App Design. The original project is available at https://www.figma.com/design/MPkpXMBXOWaBapGQQWw85l/Natek-Communication-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  