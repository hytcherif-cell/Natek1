export const avatars = {
  boy1: '👦',
  boy2: '🧒',
  boy3: '👨‍🦱',
  girl1: '👧',
  girl2: '👧🏻',
  girl3: '👩‍🦰',
  neutral1: '😊',
  neutral2: '🙂',
  neutral3: '😃',
};

export type AvatarType = keyof typeof avatars;

export const getAvatar = (avatarKey: string): string => {
  return avatars[avatarKey as AvatarType] || avatars.boy1;
};
