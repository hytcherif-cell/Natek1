import { useNavigate } from 'react-router';
import { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Language, translations } from '../utils/translations';
import { CardWithAvatar } from '../components/CardWithAvatar';

export function MealTimeScreen() {
  const navigate = useNavigate();
  const [language, setLanguage] = useState<Language>('en');
  const [avatar, setAvatar] = useState<string>('boy1');

  useEffect(() => {
    const lang = localStorage.getItem('language') as Language;
    const savedAvatar = localStorage.getItem('avatar');
    if (lang) setLanguage(lang);
    if (savedAvatar) setAvatar(savedAvatar);
  }, []);

  const t = translations[language];
  const isRTL = language === 'ar';

  const needs = [
    { id: 'eat', label: t.eat, emoji: '🍽️', color: 'from-orange-400 via-amber-400 to-yellow-400' },
    { id: 'drink', label: t.drink, emoji: '🥤', color: 'from-blue-400 via-cyan-400 to-sky-400' },
    { id: 'hunger', label: t.hunger, emoji: '🍎', color: 'from-red-400 via-rose-400 to-pink-400' },
    { id: 'thirst', label: t.thirst, emoji: '💧', color: 'from-cyan-400 via-blue-400 to-indigo-400' },
    { id: 'more', label: t.more, emoji: '➕', color: 'from-green-400 via-emerald-400 to-teal-400' },
    { id: 'done', label: t.done, emoji: '✅', color: 'from-lime-400 via-green-400 to-emerald-400' },
    { id: 'hot', label: t.hot, emoji: '🔥', color: 'from-red-500 via-orange-500 to-amber-500' },
    { id: 'cold', label: t.cold, emoji: '🧊', color: 'from-sky-400 via-blue-400 to-cyan-400' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-100 via-emerald-50 to-teal-100" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-md mx-auto min-h-screen bg-white/70 backdrop-blur-xl shadow-2xl px-10 py-12">
        {/* Back Button */}
        <button
          onClick={() => navigate('/routine')}
          className={`mb-10 flex items-center gap-3 px-5 py-3 bg-white/90 border-2 border-green-200 rounded-full shadow-sm hover:shadow-md hover:border-green-300 transition-all duration-300 active:scale-95 ${isRTL ? 'flex-row-reverse' : ''}`}
        >
          <ArrowLeft className={`w-6 h-6 text-green-600 ${isRTL ? 'rotate-180' : ''}`} />
          <span className="text-lg text-green-700">{t.back}</span>
        </button>

        {/* Title */}
        <div className="mb-12">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-gradient-to-br from-green-400 to-emerald-500 rounded-2xl p-3 shadow-lg">
              <span className="text-4xl">🍽️</span>
            </div>
            <h1 className={`text-4xl text-gray-900 tracking-tight ${isRTL ? 'text-right' : ''}`}>
              {t.mealTime}
            </h1>
          </div>
          <p className={`text-xl text-green-700 ${isRTL ? 'text-right' : ''}`}>{t.whatDoYouNeed}</p>
        </div>

        {/* Communication Cards Grid */}
        <div className="grid grid-cols-2 gap-5">
          {needs.map((need) => (
            <CardWithAvatar
              key={need.id}
              emoji={need.emoji}
              label={need.label}
              color={need.color}
              avatarKey={avatar}
              showAvatar={true}
              onClick={() => navigate(`/result/meal/${need.id}`)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
