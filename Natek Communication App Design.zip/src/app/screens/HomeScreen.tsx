import { useNavigate } from 'react-router';
import { useEffect, useState } from 'react';
import { MessageCircle, Hand, Sparkles, LogOut, User } from 'lucide-react';
import logo from 'figma:asset/d0cae9ae155f412352cb9d86e5bc655be29437df.png';
import { Language, translations } from '../utils/translations';
import { AvatarType, getAvatar } from '../utils/avatars';
import { AvatarSelectionModal } from '../components/AvatarSelectionModal';

export function HomeScreen() {
  const navigate = useNavigate();
  const [childName, setChildName] = useState('Adam');
  const [childAge, setChildAge] = useState('8');
  const [language, setLanguage] = useState<Language>('en');
  const [avatar, setAvatar] = useState<string>('boy1');
  const [showAvatarModal, setShowAvatarModal] = useState(false);

  useEffect(() => {
    const name = localStorage.getItem('childName');
    const age = localStorage.getItem('childAge');
    const lang = localStorage.getItem('language') as Language;
    const savedAvatar = localStorage.getItem('avatar');
    if (name) setChildName(name);
    if (age) setChildAge(age);
    if (lang) setLanguage(lang);
    if (savedAvatar) setAvatar(savedAvatar);
  }, []);

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('language', lang);
  };

  const handleAvatarChange = (newAvatar: AvatarType) => {
    setAvatar(newAvatar);
    localStorage.setItem('avatar', newAvatar);
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  const t = translations[language];
  const isRTL = language === 'ar';

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-100 via-blue-50 to-indigo-100" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-md mx-auto min-h-screen bg-white/80 backdrop-blur-xl shadow-2xl px-10 py-12">
        {/* Header with Logo, Language Selector, and Logout */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="absolute inset-0 bg-blue-400/20 rounded-full blur-xl"></div>
              <img src={logo} alt="Natek" className="w-16 h-16 relative drop-shadow-lg" />
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Language Selector */}
            <div className="flex bg-white border-2 border-gray-200 rounded-full p-1.5 shadow-sm">
              <button
                onClick={() => handleLanguageChange('en')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  language === 'en'
                    ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-md'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => handleLanguageChange('fr')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  language === 'fr'
                    ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-md'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                FR
              </button>
              <button
                onClick={() => handleLanguageChange('ar')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  language === 'ar'
                    ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-md'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                AR
              </button>
            </div>

            {/* Logout Button */}
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2.5 bg-white border-2 border-gray-200 rounded-full shadow-sm hover:shadow-md hover:border-red-300 transition-all duration-300 active:scale-95 group"
            >
              <LogOut className="w-4 h-4 text-gray-600 group-hover:text-red-500 transition-colors" />
            </button>
          </div>
        </div>

        {/* Profile Section */}
        <div className="bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-600 rounded-[2rem] p-8 shadow-xl mb-12 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full blur-2xl"></div>
          <div className={`flex items-center gap-6 relative ${isRTL ? 'flex-row-reverse' : ''}`}>
            <button 
              onClick={() => setShowAvatarModal(true)}
              className="w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-lg flex-shrink-0 ring-4 ring-white/30 hover:ring-white/50 transition-all duration-300 hover:scale-105 active:scale-95 group relative"
            >
              <span className="text-6xl">{getAvatar(avatar)}</span>
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 rounded-full transition-all duration-300 flex items-center justify-center">
                <User className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </button>
            <div className={isRTL ? 'text-right' : ''}>
              <h1 className="text-4xl text-white tracking-tight mb-1">
                {childName}
              </h1>
              <p className="text-xl text-blue-100">
                {childAge} {t.yearsOld}
              </p>
            </div>
          </div>
        </div>

        {/* Feature Cards */}
        <div className="space-y-6">
          {/* Daily Communication - Active */}
          <button
            onClick={() => navigate('/routine')}
            className="w-full bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-600 rounded-[2rem] p-8 shadow-xl hover:shadow-2xl transition-all duration-300 active:scale-[0.98] hover:scale-[1.02] text-left relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl group-hover:blur-3xl transition-all"></div>
            <div className={`flex items-center gap-6 mb-3 relative ${isRTL ? 'flex-row-reverse' : ''}`}>
              <div className="bg-white/20 rounded-3xl p-5 backdrop-blur-sm shadow-lg ring-2 ring-white/30">
                <MessageCircle className="w-12 h-12 text-white" strokeWidth={2.5} />
              </div>
              <div className={`flex-1 ${isRTL ? 'text-right' : ''}`}>
                <h2 className="text-3xl text-white tracking-tight">
                  {t.dailyCommunication}
                </h2>
              </div>
            </div>
            <p className={`text-lg text-blue-100 relative ${isRTL ? 'mr-[100px] text-right' : 'ml-[100px]'}`}>
              {t.dailyCommunicationDesc}
            </p>
          </button>

          {/* Learn Sign Language - Coming Soon */}
          <div className="w-full bg-white rounded-[2rem] p-8 shadow-md border-2 border-gray-200 relative overflow-hidden">
            <div className={`absolute top-5 ${isRTL ? 'left-5' : 'right-5'} bg-gradient-to-r from-yellow-400 to-orange-400 text-white px-5 py-2 rounded-full text-sm font-medium shadow-md`}>
              {t.comingSoon}
            </div>
            <div className={`flex items-center gap-6 mb-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <div className="bg-gray-100 rounded-3xl p-5 shadow-sm">
                <Hand className="w-12 h-12 text-gray-500" strokeWidth={2.5} />
              </div>
              <div className={`flex-1 ${isRTL ? 'text-right' : ''}`}>
                <h2 className="text-3xl text-gray-400 tracking-tight">
                  {t.learnSignLanguage}
                </h2>
              </div>
            </div>
            <p className={`text-lg text-gray-400 ${isRTL ? 'mr-[100px] text-right' : 'ml-[100px]'}`}>
              {t.learnSignLanguageDesc}
            </p>
          </div>

          {/* AI Translation - In Development */}
          <div className="w-full bg-white rounded-[2rem] p-8 shadow-md border-2 border-gray-200 relative overflow-hidden">
            <div className={`absolute top-5 ${isRTL ? 'left-5' : 'right-5'} bg-gradient-to-r from-purple-400 to-pink-400 text-white px-5 py-2 rounded-full text-sm font-medium shadow-md`}>
              {t.inDevelopment}
            </div>
            <div className={`flex items-center gap-6 mb-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <div className="bg-gray-100 rounded-3xl p-5 shadow-sm">
                <Sparkles className="w-12 h-12 text-gray-500" strokeWidth={2.5} />
              </div>
              <div className={`flex-1 ${isRTL ? 'text-right' : ''}`}>
                <h2 className="text-3xl text-gray-400 tracking-tight">
                  {t.aiTranslation}
                </h2>
              </div>
            </div>
            <p className={`text-lg text-gray-400 ${isRTL ? 'mr-[100px] text-right' : 'ml-[100px]'}`}>
              {t.aiTranslationDesc}
            </p>
          </div>
        </div>
      </div>

      {/* Avatar Selection Modal */}
      <AvatarSelectionModal
        isOpen={showAvatarModal}
        onClose={() => setShowAvatarModal(false)}
        onSelect={handleAvatarChange}
        currentAvatar={avatar}
        language={language}
      />
    </div>
  );
}