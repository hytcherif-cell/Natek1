import { useNavigate } from 'react-router';
import { useState, useEffect } from 'react';
import { Sun, Moon, ArrowLeft, Utensils, Play, School, Heart, Sparkles } from 'lucide-react';
import { Language, translations } from '../utils/translations';

export function RoutineScreen() {
  const navigate = useNavigate();
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    const lang = localStorage.getItem('language') as Language;
    if (lang) setLanguage(lang);
  }, []);

  const t = translations[language];
  const isRTL = language === 'ar';

  const routines = [
    {
      path: '/before-going-out',
      icon: <Sun className="w-20 h-20 text-white" strokeWidth={2.5} />,
      label: t.beforeGoingOut,
      color: 'from-amber-400 via-orange-400 to-yellow-500',
    },
    {
      path: '/before-bed',
      icon: <Moon className="w-20 h-20 text-white" strokeWidth={2.5} />,
      label: t.beforeBed,
      color: 'from-indigo-500 via-purple-500 to-violet-600',
    },
    {
      path: '/meal-time',
      icon: <Utensils className="w-20 h-20 text-white" strokeWidth={2.5} />,
      label: t.mealTime,
      color: 'from-green-400 via-emerald-500 to-teal-600',
    },
    {
      path: '/play-time',
      icon: <Play className="w-20 h-20 text-white" strokeWidth={2.5} />,
      label: t.playTime,
      color: 'from-pink-400 via-rose-500 to-red-500',
    },
    {
      path: '/school-time',
      icon: <School className="w-20 h-20 text-white" strokeWidth={2.5} />,
      label: t.schoolTime,
      color: 'from-blue-400 via-cyan-500 to-sky-600',
    },
    {
      path: '/feelings',
      icon: <Heart className="w-20 h-20 text-white" strokeWidth={2.5} />,
      label: t.feelings,
      color: 'from-purple-400 via-fuchsia-500 to-pink-600',
    },
    {
      path: '/personalized',
      icon: <Sparkles className="w-20 h-20 text-white" strokeWidth={2.5} />,
      label: t.personalized,
      color: 'from-violet-400 via-purple-500 to-fuchsia-600',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-100 via-blue-50 to-indigo-100" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-md mx-auto min-h-screen bg-white/80 backdrop-blur-xl shadow-2xl px-10 py-12">
        {/* Back Button */}
        <button
          onClick={() => navigate('/home')}
          className={`mb-10 flex items-center gap-3 px-5 py-3 bg-white border-2 border-gray-200 rounded-full shadow-sm hover:shadow-md hover:border-blue-300 transition-all duration-300 active:scale-95 ${isRTL ? 'flex-row-reverse' : ''}`}
        >
          <ArrowLeft className={`w-6 h-6 text-gray-600 ${isRTL ? 'rotate-180' : ''}`} />
          <span className="text-lg text-gray-700">{t.back}</span>
        </button>

        {/* Title */}
        <h1 className={`text-4xl text-gray-900 mb-12 tracking-tight ${isRTL ? 'text-right' : ''}`}>
          {t.chooseRoutine}
        </h1>

        {/* Routine Buttons */}
        <div className="space-y-5">
          {routines.map((routine) => (
            <button
              key={routine.path}
              onClick={() => navigate(routine.path)}
              className={`w-full bg-gradient-to-br ${routine.color} rounded-[2rem] px-8 py-10 shadow-xl hover:shadow-2xl transition-all duration-300 active:scale-[0.98] hover:scale-[1.02] relative overflow-hidden group`}
            >
              <div className="absolute top-0 right-0 w-40 h-40 bg-white/20 rounded-full blur-3xl group-hover:blur-2xl transition-all"></div>
              <div className={`flex items-center gap-7 relative ${isRTL ? 'flex-row-reverse' : ''}`}>
                <div className="flex-shrink-0 bg-white/30 rounded-3xl p-6 backdrop-blur-sm shadow-lg ring-2 ring-white/40">
                  {routine.icon}
                </div>
                <span className={`text-3xl text-white flex-1 tracking-tight leading-tight ${isRTL ? 'text-right' : 'text-left'}`}>
                  {routine.label}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}