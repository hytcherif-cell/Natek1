import { useNavigate } from 'react-router';
import { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Language, translations } from '../utils/translations';
import { CardWithAvatar } from '../components/CardWithAvatar';

export function PlayTimeScreen() {
  const navigate = useNavigate();
  const [language, setLanguage] = useState<Language>('en');
  const [avatar, setAvatar] = useState<string>('boy1');

  useEffect(() => {
    const lang = localStorage.getItem('language') as Language;
    const savedAvatar = localStorage.getItem('avatar');
    if (lang) setLanguage(lang);
    if (savedAvatar) setAvatar(savedAvatar);
  }, []);

  const t = translations[language];
  const isRTL = language === 'ar';

  const needs = [
    { id: 'play', label: t.play, emoji: '🎮', color: 'from-pink-400 via-rose-400 to-red-400' },
    { id: 'toys', label: t.toys, emoji: '🧸', color: 'from-purple-400 via-fuchsia-400 to-pink-400' },
    { id: 'outside', label: t.outside, emoji: '🌳', color: 'from-green-400 via-lime-400 to-emerald-400' },
    { id: 'friend', label: t.friend, emoji: '👫', color: 'from-blue-400 via-sky-400 to-cyan-400' },
    { id: 'thirst', label: t.thirst, emoji: '💧', color: 'from-cyan-400 via-blue-400 to-indigo-400' },
    { id: 'tired', label: t.tired, emoji: '😴', color: 'from-violet-400 via-purple-400 to-indigo-400' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-rose-50 to-red-100" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-md mx-auto min-h-screen bg-white/70 backdrop-blur-xl shadow-2xl px-10 py-12">
        {/* Back Button */}
        <button
          onClick={() => navigate('/routine')}
          className={`mb-10 flex items-center gap-3 px-5 py-3 bg-white/90 border-2 border-pink-200 rounded-full shadow-sm hover:shadow-md hover:border-pink-300 transition-all duration-300 active:scale-95 ${isRTL ? 'flex-row-reverse' : ''}`}
        >
          <ArrowLeft className={`w-6 h-6 text-pink-600 ${isRTL ? 'rotate-180' : ''}`} />
          <span className="text-lg text-pink-700">{t.back}</span>
        </button>

        {/* Title */}
        <div className="mb-12">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-gradient-to-br from-pink-400 to-rose-500 rounded-2xl p-3 shadow-lg">
              <span className="text-4xl">🎮</span>
            </div>
            <h1 className={`text-4xl text-gray-900 tracking-tight ${isRTL ? 'text-right' : ''}`}>
              {t.playTime}
            </h1>
          </div>
          <p className={`text-xl text-pink-700 ${isRTL ? 'text-right' : ''}`}>{t.whatDoYouNeed}</p>
        </div>

        {/* Communication Cards Grid */}
        <div className="grid grid-cols-2 gap-5">
          {needs.map((need) => (
            <CardWithAvatar
              key={need.id}
              emoji={need.emoji}
              label={need.label}
              color={need.color}
              avatarKey={avatar}
              showAvatar={true}
              onClick={() => navigate(`/result/play/${need.id}`)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
