import { useEffect } from 'react';
import { useNavigate } from 'react-router';
import logo from 'figma:asset/d0cae9ae155f412352cb9d86e5bc655be29437df.png';

export function SplashScreen() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/login');
    }, 2500);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-100 via-blue-50 to-indigo-100 flex items-center justify-center px-8">
      <div className="text-center">
        <div className="mb-12 animate-fade-in">
          <div className="relative inline-block">
            <div className="absolute inset-0 bg-blue-400/30 rounded-full blur-3xl animate-pulse"></div>
            <img src={logo} alt="Natek" className="w-48 h-48 mx-auto relative drop-shadow-2xl" />
          </div>
        </div>
        <h1 className="text-5xl text-gray-900 mb-6 tracking-tight animate-fade-in">
          Natek
        </h1>
        <p className="text-2xl text-gray-600 animate-fade-in max-w-md mx-auto leading-relaxed">
          Every need, clearly understood.
        </p>
      </div>
    </div>
  );
}