import { useNavigate, useParams } from 'react-router';
import { useState, useEffect } from 'react';
import { Volume2, ArrowLeft, Home } from 'lucide-react';
import { Language, translations } from '../utils/translations';
import { getAvatar } from '../utils/avatars';

export function ResultScreen() {
  const navigate = useNavigate();
  const { routine, need } = useParams<{ routine: string; need: string }>();
  const [language, setLanguage] = useState<Language>('en');
  const [avatar, setAvatar] = useState<string>('boy1');

  useEffect(() => {
    const lang = localStorage.getItem('language') as Language;
    const savedAvatar = localStorage.getItem('avatar');
    if (lang) setLanguage(lang);
    if (savedAvatar) setAvatar(savedAvatar);
  }, []);

  const t = translations[language];
  const isRTL = language === 'ar';

  // Check if it's a custom card
  const isCustomCard = routine === 'custom';
  let customCardData = null;
  
  if (isCustomCard) {
    const savedCards = localStorage.getItem('customCards');
    if (savedCards) {
      const cards = JSON.parse(savedCards);
      customCardData = cards.find((card: any) => card.id === need);
    }
  }

  const needsData: Record<string, { label: string; emoji: string; color: string; instruction: string }> = {
    // Going Out
    toilet: {
      label: t.toilet.toUpperCase(),
      emoji: '🚽',
      color: 'from-yellow-400 via-amber-400 to-orange-400',
      instruction: t.toiletInstruction,
    },
    thirst: {
      label: t.thirst.toUpperCase(),
      emoji: '💧',
      color: 'from-cyan-400 via-blue-400 to-sky-400',
      instruction: t.thirstInstruction,
    },
    hunger: {
      label: t.hunger.toUpperCase(),
      emoji: '🍎',
      color: 'from-emerald-400 via-green-400 to-teal-400',
      instruction: t.hungerInstruction,
    },
    ready: {
      label: t.ready.toUpperCase(),
      emoji: '👍',
      color: 'from-orange-400 via-amber-500 to-yellow-500',
      instruction: t.readyInstruction,
    },
    shoes: {
      label: t.shoes.toUpperCase(),
      emoji: '👟',
      color: 'from-blue-400 via-indigo-400 to-purple-400',
      instruction: t.shoesInstruction,
    },
    coat: {
      label: t.coat.toUpperCase(),
      emoji: '🧥',
      color: 'from-red-400 via-rose-400 to-pink-400',
      instruction: t.coatInstruction,
    },
    bag: {
      label: t.bag.toUpperCase(),
      emoji: '🎒',
      color: 'from-purple-400 via-violet-400 to-indigo-400',
      instruction: t.bagInstruction,
    },
    keys: {
      label: t.keys.toUpperCase(),
      emoji: '🔑',
      color: 'from-yellow-500 via-orange-500 to-amber-600',
      instruction: t.keysInstruction,
    },
    // Bed Time
    water: {
      label: t.water.toUpperCase(),
      emoji: '💧',
      color: 'from-blue-400 via-cyan-400 to-sky-400',
      instruction: t.waterInstruction,
    },
    sleep: {
      label: t.sleep.toUpperCase(),
      emoji: '😴',
      color: 'from-indigo-400 via-violet-400 to-purple-400',
      instruction: t.sleepInstruction,
    },
    tired: {
      label: t.tired.toUpperCase(),
      emoji: '🥱',
      color: 'from-violet-400 via-purple-400 to-pink-400',
      instruction: t.tiredInstruction,
    },
    brush: {
      label: t.brush.toUpperCase(),
      emoji: '🪥',
      color: 'from-cyan-400 via-teal-400 to-blue-400',
      instruction: t.brushInstruction,
    },
    pajamas: {
      label: t.pajamas.toUpperCase(),
      emoji: '👕',
      color: 'from-pink-400 via-rose-400 to-red-400',
      instruction: t.pajamasInstruction,
    },
    story: {
      label: t.story.toUpperCase(),
      emoji: '📖',
      color: 'from-amber-400 via-yellow-400 to-orange-400',
      instruction: t.storyInstruction,
    },
    // Meal Time
    eat: {
      label: t.eat.toUpperCase(),
      emoji: '🍽️',
      color: 'from-orange-400 via-amber-400 to-yellow-400',
      instruction: t.eatInstruction,
    },
    drink: {
      label: t.drink.toUpperCase(),
      emoji: '🥤',
      color: 'from-blue-400 via-cyan-400 to-sky-400',
      instruction: t.drinkInstruction,
    },
    more: {
      label: t.more.toUpperCase(),
      emoji: '➕',
      color: 'from-green-400 via-emerald-400 to-teal-400',
      instruction: t.moreInstruction,
    },
    done: {
      label: t.done.toUpperCase(),
      emoji: '✅',
      color: 'from-lime-400 via-green-400 to-emerald-400',
      instruction: t.doneInstruction,
    },
    hot: {
      label: t.hot.toUpperCase(),
      emoji: '🔥',
      color: 'from-red-500 via-orange-500 to-amber-500',
      instruction: t.hotInstruction,
    },
    cold: {
      label: t.cold.toUpperCase(),
      emoji: '🧊',
      color: 'from-sky-400 via-blue-400 to-cyan-400',
      instruction: t.coldInstruction,
    },
    // Play Time
    play: {
      label: t.play.toUpperCase(),
      emoji: '🎮',
      color: 'from-pink-400 via-rose-400 to-red-400',
      instruction: t.playInstruction,
    },
    toys: {
      label: t.toys.toUpperCase(),
      emoji: '🧸',
      color: 'from-purple-400 via-fuchsia-400 to-pink-400',
      instruction: t.toysInstruction,
    },
    outside: {
      label: t.outside.toUpperCase(),
      emoji: '🌳',
      color: 'from-green-400 via-lime-400 to-emerald-400',
      instruction: t.outsideInstruction,
    },
    friend: {
      label: t.friend.toUpperCase(),
      emoji: '👫',
      color: 'from-blue-400 via-sky-400 to-cyan-400',
      instruction: t.friendInstruction,
    },
    // School Time
    school: {
      label: t.school.toUpperCase(),
      emoji: '🏫',
      color: 'from-blue-400 via-indigo-400 to-purple-400',
      instruction: t.schoolInstruction,
    },
    book: {
      label: t.book.toUpperCase(),
      emoji: '📚',
      color: 'from-cyan-400 via-sky-400 to-blue-400',
      instruction: t.bookInstruction,
    },
    help: {
      label: t.help.toUpperCase(),
      emoji: '🙋',
      color: 'from-orange-400 via-amber-400 to-yellow-400',
      instruction: t.helpInstruction,
    },
    break: {
      label: t.break.toUpperCase(),
      emoji: '⏸️',
      color: 'from-green-400 via-emerald-400 to-teal-400',
      instruction: t.breakInstruction,
    },
    // Feelings
    happy: {
      label: t.happy.toUpperCase(),
      emoji: '😊',
      color: 'from-yellow-400 via-amber-400 to-orange-400',
      instruction: t.happyInstruction,
    },
    sad: {
      label: t.sad.toUpperCase(),
      emoji: '😢',
      color: 'from-blue-400 via-cyan-400 to-sky-400',
      instruction: t.sadInstruction,
    },
    angry: {
      label: t.angry.toUpperCase(),
      emoji: '😠',
      color: 'from-red-400 via-rose-400 to-pink-400',
      instruction: t.angryInstruction,
    },
    scared: {
      label: t.scared.toUpperCase(),
      emoji: '😨',
      color: 'from-purple-400 via-violet-400 to-indigo-400',
      instruction: t.scaredInstruction,
    },
    excited: {
      label: t.excited.toUpperCase(),
      emoji: '🤩',
      color: 'from-orange-400 via-amber-400 to-yellow-400',
      instruction: t.excitedInstruction,
    },
    calm: {
      label: t.calm.toUpperCase(),
      emoji: '😌',
      color: 'from-green-400 via-emerald-400 to-teal-400',
      instruction: t.calmInstruction,
    },
  };

  const currentNeed = customCardData 
    ? {
        label: customCardData.label.toUpperCase(),
        emoji: customCardData.emoji,
        color: customCardData.color,
        instruction: `Your child chose ${customCardData.label}.`,
      }
    : needsData[need || 'toilet'];

  const isBedRoutine = routine === 'bed';

  const playAudio = () => {
    const utterance = new SpeechSynthesisUtterance(currentNeed.label);
    utterance.rate = 0.8;
    utterance.pitch = 1.2;
    utterance.lang = language === 'ar' ? 'ar-SA' : language === 'fr' ? 'fr-FR' : 'en-US';
    window.speechSynthesis.speak(utterance);
  };

  const bgGradient = isBedRoutine 
    ? 'from-indigo-900 via-purple-800 to-blue-900'
    : 'from-sky-100 via-blue-50 to-indigo-100';
  
  const containerBg = isBedRoutine
    ? 'bg-indigo-950/40'
    : 'bg-white/80';

  return (
    <div className={`min-h-screen bg-gradient-to-br ${bgGradient}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <div className={`max-w-md mx-auto min-h-screen ${containerBg} backdrop-blur-xl shadow-2xl px-10 py-12`}>
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className={`mb-10 flex items-center gap-3 px-5 py-3 ${
            isBedRoutine 
              ? 'bg-white/10 border-2 border-indigo-400/30 text-indigo-100 hover:border-indigo-300/50'
              : 'bg-white border-2 border-gray-200 text-gray-700 hover:border-blue-300'
          } rounded-full shadow-sm hover:shadow-md transition-all duration-300 active:scale-95 backdrop-blur-md ${isRTL ? 'flex-row-reverse' : ''}`}
        >
          <ArrowLeft className={`w-6 h-6 ${isRTL ? 'rotate-180' : ''}`} />
          <span className="text-lg">{t.back}</span>
        </button>

        {/* Result Card */}
        <div className="text-center mt-8">
          {/* Large Emoji Illustration with Avatar */}
          <div className={`inline-flex bg-gradient-to-br ${currentNeed.color} rounded-full p-16 shadow-2xl mb-10 relative overflow-hidden group ${isBedRoutine ? 'ring-4 ring-white/20' : ''}`}>
            <div className="absolute inset-0 bg-white/20 rounded-full blur-2xl"></div>
            
            {/* Avatar in corner */}
            <div className="absolute top-4 right-4 w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-lg ring-4 ring-white/50 z-10">
              <span className="text-4xl">{getAvatar(avatar)}</span>
            </div>
            
            <span className="text-[10rem] relative z-10 drop-shadow-2xl">{currentNeed.emoji}</span>
          </div>

          {/* Need Label */}
          <h1 className={`text-6xl mb-8 tracking-tight ${isBedRoutine ? 'text-white' : 'text-gray-900'}`}>
            {currentNeed.label}
          </h1>

          {/* Audio Play Button */}
          <button
            onClick={playAudio}
            className="mb-12 bg-gradient-to-r from-blue-500 to-indigo-600 text-white p-7 rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 active:scale-95 hover:scale-110 ring-4 ring-blue-200"
          >
            <Volume2 className="w-12 h-12" strokeWidth={2.5} />
          </button>

          {/* Instruction Text */}
          <div className={`${
            isBedRoutine
              ? 'bg-white/10 border-2 border-indigo-400/30 backdrop-blur-md'
              : 'bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-100'
          } rounded-[2rem] p-8 shadow-lg mb-10`}>
            <p className={`text-xl leading-relaxed ${isBedRoutine ? 'text-indigo-100' : 'text-gray-800'} ${isRTL ? 'text-right' : ''}`}>
              {currentNeed.instruction}
            </p>
          </div>

          {/* Home Button */}
          <button
            onClick={() => navigate('/home')}
            className={`w-full ${
              isBedRoutine
                ? 'bg-white/10 border-2 border-indigo-400/30 text-white hover:border-indigo-300/50 backdrop-blur-md'
                : 'bg-white border-2 border-gray-200 text-gray-800 hover:border-blue-300'
            } text-xl py-6 rounded-full shadow-md hover:shadow-xl transition-all duration-300 active:scale-[0.98] flex items-center justify-center gap-3 font-medium ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <Home className="w-6 h-6" />
            <span>{t.returnHome}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
