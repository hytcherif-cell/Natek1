import { useNavigate } from 'react-router';
import { useState, useEffect } from 'react';
import { ArrowLeft, Plus, Edit2, Trash2 } from 'lucide-react';
import { Language, translations } from '../utils/translations';
import { CardWithAvatar } from '../components/CardWithAvatar';

interface CustomCard {
  id: string;
  emoji: string;
  label: string;
  color: string;
}

const emojiOptions = ['😊', '🎨', '⚽', '🎵', '📱', '🍕', '🚗', '🏠', '💊', '🩹', '🛁', '🪞', '🧴', '👔', '🧦', '🧢'];
const colorOptions = [
  'from-red-400 via-rose-400 to-pink-400',
  'from-orange-400 via-amber-400 to-yellow-400',
  'from-yellow-400 via-lime-400 to-green-400',
  'from-green-400 via-emerald-400 to-teal-400',
  'from-cyan-400 via-sky-400 to-blue-400',
  'from-blue-400 via-indigo-400 to-purple-400',
  'from-purple-400 via-violet-400 to-fuchsia-400',
  'from-pink-400 via-rose-400 to-red-400',
];

export function PersonalizedScreen() {
  const navigate = useNavigate();
  const [language, setLanguage] = useState<Language>('en');
  const [avatar, setAvatar] = useState<string>('boy1');
  const [customCards, setCustomCards] = useState<CustomCard[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingCard, setEditingCard] = useState<CustomCard | null>(null);
  const [newCardLabel, setNewCardLabel] = useState('');
  const [selectedEmoji, setSelectedEmoji] = useState('😊');
  const [selectedColor, setSelectedColor] = useState(colorOptions[0]);

  useEffect(() => {
    const lang = localStorage.getItem('language') as Language;
    const savedAvatar = localStorage.getItem('avatar');
    const savedCards = localStorage.getItem('customCards');
    
    if (lang) setLanguage(lang);
    if (savedAvatar) setAvatar(savedAvatar);
    if (savedCards) {
      setCustomCards(JSON.parse(savedCards));
    }
  }, []);

  const saveCards = (cards: CustomCard[]) => {
    localStorage.setItem('customCards', JSON.stringify(cards));
    setCustomCards(cards);
  };

  const handleCreateCard = () => {
    if (!newCardLabel.trim()) return;

    const newCard: CustomCard = {
      id: `custom-${Date.now()}`,
      emoji: selectedEmoji,
      label: newCardLabel,
      color: selectedColor,
    };

    if (editingCard) {
      const updatedCards = customCards.map(card => 
        card.id === editingCard.id ? { ...newCard, id: editingCard.id } : card
      );
      saveCards(updatedCards);
    } else {
      saveCards([...customCards, newCard]);
    }

    resetModal();
  };

  const handleDeleteCard = (id: string) => {
    saveCards(customCards.filter(card => card.id !== id));
  };

  const handleEditCard = (card: CustomCard) => {
    setEditingCard(card);
    setNewCardLabel(card.label);
    setSelectedEmoji(card.emoji);
    setSelectedColor(card.color);
    setShowCreateModal(true);
  };

  const resetModal = () => {
    setShowCreateModal(false);
    setEditingCard(null);
    setNewCardLabel('');
    setSelectedEmoji('😊');
    setSelectedColor(colorOptions[0]);
  };

  const t = translations[language];
  const isRTL = language === 'ar';

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-50 to-rose-100" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-md mx-auto min-h-screen bg-white/70 backdrop-blur-xl shadow-2xl px-10 py-12">
        {/* Back Button */}
        <button
          onClick={() => navigate('/routine')}
          className={`mb-10 flex items-center gap-3 px-5 py-3 bg-white/90 border-2 border-purple-200 rounded-full shadow-sm hover:shadow-md hover:border-purple-300 transition-all duration-300 active:scale-95 ${isRTL ? 'flex-row-reverse' : ''}`}
        >
          <ArrowLeft className={`w-6 h-6 text-purple-600 ${isRTL ? 'rotate-180' : ''}`} />
          <span className="text-lg text-purple-700">{t.back}</span>
        </button>

        {/* Title */}
        <div className="mb-12 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-4 mb-2">
              <div className="bg-gradient-to-br from-purple-400 to-pink-500 rounded-2xl p-3 shadow-lg">
                <span className="text-4xl">✨</span>
              </div>
              <h1 className={`text-4xl text-gray-900 tracking-tight ${isRTL ? 'text-right' : ''}`}>
                {t.myCards}
              </h1>
            </div>
            <p className={`text-lg text-purple-700 ${isRTL ? 'text-right' : ''}`}>{t.personalized}</p>
          </div>
          
          {/* Add Button */}
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-gradient-to-br from-purple-500 to-pink-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 active:scale-95 hover:scale-110"
          >
            <Plus className="w-7 h-7" strokeWidth={2.5} />
          </button>
        </div>

        {/* Custom Cards Grid */}
        {customCards.length > 0 ? (
          <div className="grid grid-cols-2 gap-5">
            {customCards.map((card) => (
              <div key={card.id} className="relative">
                <CardWithAvatar
                  emoji={card.emoji}
                  label={card.label}
                  color={card.color}
                  avatarKey={avatar}
                  showAvatar={true}
                  onClick={() => navigate(`/result/custom/${card.id}`)}
                />
                
                {/* Edit/Delete Buttons */}
                <div className="absolute top-2 right-2 flex gap-1 z-20">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleEditCard(card);
                    }}
                    className="bg-white/90 p-2 rounded-full shadow-md hover:shadow-lg transition-all active:scale-95"
                  >
                    <Edit2 className="w-4 h-4 text-blue-600" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteCard(card.id);
                    }}
                    className="bg-white/90 p-2 rounded-full shadow-md hover:shadow-lg transition-all active:scale-95"
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="text-8xl mb-6">📝</div>
            <p className="text-2xl text-gray-600 mb-2">{t.noCustomCards}</p>
            <p className="text-lg text-gray-500">{t.tapToCreate}</p>
          </div>
        )}
      </div>

      {/* Create/Edit Card Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6" onClick={resetModal}>
          <div 
            className="bg-white rounded-[2rem] p-8 max-w-md w-full shadow-2xl max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
            dir={isRTL ? 'rtl' : 'ltr'}
          >
            <h2 className={`text-3xl text-gray-900 mb-8 tracking-tight ${isRTL ? 'text-right' : ''}`}>
              {editingCard ? t.editCard : t.createCard}
            </h2>
            
            {/* Card Name Input */}
            <div className="mb-6">
              <label className={`block text-lg text-gray-700 mb-3 ${isRTL ? 'text-right' : ''}`}>
                {t.cardName}
              </label>
              <input
                type="text"
                value={newCardLabel}
                onChange={(e) => setNewCardLabel(e.target.value)}
                placeholder={t.cardName}
                className="w-full px-6 py-4 bg-gray-50 border-2 border-gray-200 rounded-2xl text-lg focus:outline-none focus:border-purple-400 focus:ring-4 focus:ring-purple-100 transition-all"
              />
            </div>

            {/* Emoji Selection */}
            <div className="mb-6">
              <label className={`block text-lg text-gray-700 mb-3 ${isRTL ? 'text-right' : ''}`}>
                {t.selectEmoji}
              </label>
              <div className="grid grid-cols-4 gap-3">
                {emojiOptions.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => setSelectedEmoji(emoji)}
                    className={`aspect-square rounded-2xl flex items-center justify-center text-5xl transition-all duration-300 hover:scale-110 ${
                      selectedEmoji === emoji
                        ? 'bg-purple-100 ring-4 ring-purple-400 shadow-lg'
                        : 'bg-gray-100 hover:bg-gray-200'
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>

            {/* Color Selection */}
            <div className="mb-8">
              <label className={`block text-lg text-gray-700 mb-3 ${isRTL ? 'text-right' : ''}`}>
                Color
              </label>
              <div className="grid grid-cols-4 gap-3">
                {colorOptions.map((color) => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`aspect-square rounded-2xl bg-gradient-to-br ${color} transition-all duration-300 hover:scale-110 ${
                      selectedColor === color ? 'ring-4 ring-gray-400 shadow-lg' : 'shadow-md'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Buttons */}
            <div className="flex gap-4">
              <button
                onClick={resetModal}
                className="flex-1 py-4 bg-gray-100 text-gray-700 rounded-full text-lg font-medium hover:bg-gray-200 transition-all duration-300 active:scale-[0.98]"
              >
                {t.cancel}
              </button>
              <button
                onClick={handleCreateCard}
                disabled={!newCardLabel.trim()}
                className="flex-1 py-4 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-full text-lg font-medium hover:shadow-xl transition-all duration-300 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {t.save}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}