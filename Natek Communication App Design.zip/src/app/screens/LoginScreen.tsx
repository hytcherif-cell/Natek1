import { useState } from 'react';
import { useNavigate } from 'react-router';
import logo from 'figma:asset/d0cae9ae155f412352cb9d86e5bc655be29437df.png';
import { Language, translations } from '../utils/translations';

export function LoginScreen() {
  const navigate = useNavigate();
  const [childName, setChildName] = useState('');
  const [age, setAge] = useState('');
  const [language, setLanguage] = useState<Language>('en');

  const t = translations[language];

  const handleContinue = () => {
    if (childName && age) {
      localStorage.setItem('childName', childName);
      localStorage.setItem('childAge', age);
      localStorage.setItem('language', language);
      navigate('/home');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-100 via-blue-50 to-indigo-100">
      <div className="max-w-md mx-auto min-h-screen bg-white/80 backdrop-blur-xl shadow-2xl px-10 py-16">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <div className="relative">
            <div className="absolute inset-0 bg-blue-400/20 rounded-full blur-2xl"></div>
            <img src={logo} alt="Natek" className="w-28 h-28 relative drop-shadow-xl" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-4xl text-gray-900 text-center mb-3 tracking-tight">
          {t.welcomeTitle}
        </h1>
        <p className="text-xl text-gray-600 text-center mb-16 leading-relaxed">
          {t.welcomeSubtitle}
        </p>

        {/* Form */}
        <div className="space-y-7">
          {/* Child Name */}
          <div>
            <label className="block text-lg text-gray-700 mb-3 ml-1">
              {t.childName}
            </label>
            <input
              type="text"
              value={childName}
              onChange={(e) => setChildName(e.target.value)}
              placeholder={t.enterName}
              className="w-full px-7 py-6 bg-white border-2 border-gray-200 rounded-3xl text-xl focus:outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-100 transition-all shadow-sm hover:shadow-md"
            />
          </div>

          {/* Age */}
          <div>
            <label className="block text-lg text-gray-700 mb-3 ml-1">
              {t.age}
            </label>
            <input
              type="number"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              placeholder={t.enterAge}
              min="6"
              max="12"
              className="w-full px-7 py-6 bg-white border-2 border-gray-200 rounded-3xl text-xl focus:outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-100 transition-all shadow-sm hover:shadow-md"
            />
          </div>

          {/* Language Selection */}
          <div>
            <label className="block text-lg text-gray-700 mb-4 ml-1">
              {t.selectLanguage}
            </label>
            <div className="grid grid-cols-3 gap-4">
              <button
                onClick={() => setLanguage('en')}
                className={`py-5 rounded-2xl text-lg font-medium transition-all duration-300 ${
                  language === 'en'
                    ? 'bg-gradient-to-br from-blue-500 to-indigo-600 text-white shadow-lg scale-105'
                    : 'bg-white border-2 border-gray-200 text-gray-700 hover:border-blue-300 shadow-sm'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLanguage('fr')}
                className={`py-5 rounded-2xl text-lg font-medium transition-all duration-300 ${
                  language === 'fr'
                    ? 'bg-gradient-to-br from-blue-500 to-indigo-600 text-white shadow-lg scale-105'
                    : 'bg-white border-2 border-gray-200 text-gray-700 hover:border-blue-300 shadow-sm'
                }`}
              >
                FR
              </button>
              <button
                onClick={() => setLanguage('ar')}
                className={`py-5 rounded-2xl text-lg font-medium transition-all duration-300 ${
                  language === 'ar'
                    ? 'bg-gradient-to-br from-blue-500 to-indigo-600 text-white shadow-lg scale-105'
                    : 'bg-white border-2 border-gray-200 text-gray-700 hover:border-blue-300 shadow-sm'
                }`}
              >
                AR
              </button>
            </div>
          </div>
        </div>

        {/* Continue Button */}
        <button
          onClick={handleContinue}
          disabled={!childName || !age}
          className="w-full mt-16 bg-gradient-to-r from-blue-500 to-indigo-600 text-white text-2xl py-7 rounded-full shadow-lg hover:shadow-2xl transition-all duration-300 active:scale-[0.97] hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 font-medium"
        >
          {t.continue}
        </button>
      </div>
    </div>
  );
}