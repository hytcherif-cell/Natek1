import { useNavigate } from 'react-router';
import { ArrowLeft } from 'lucide-react';

export function CommunicationScreen() {
  const navigate = useNavigate();

  const needs = [
    { id: 'toilet', label: 'Toilet', emoji: '🚽', color: 'from-yellow-400 via-amber-400 to-orange-400' },
    { id: 'hunger', label: 'Hungry', emoji: '🍎', color: 'from-emerald-400 via-green-400 to-teal-400' },
    { id: 'thirst', label: 'Thirsty', emoji: '💧', color: 'from-cyan-400 via-blue-400 to-sky-400' },
    { id: 'pain', label: 'Pain', emoji: '🤕', color: 'from-rose-400 via-pink-400 to-red-400' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-100 via-blue-50 to-indigo-100">
      <div className="max-w-md mx-auto min-h-screen bg-white/80 backdrop-blur-xl shadow-2xl px-10 py-12">
        {/* Back Button */}
        <button
          onClick={() => navigate('/routine')}
          className="mb-10 flex items-center gap-3 px-5 py-3 bg-white border-2 border-gray-200 rounded-full shadow-sm hover:shadow-md hover:border-blue-300 transition-all duration-300 active:scale-95"
        >
          <ArrowLeft className="w-6 h-6 text-gray-600" />
          <span className="text-lg text-gray-700">Back</span>
        </button>

        {/* Title */}
        <h1 className="text-4xl text-gray-900 mb-12 tracking-tight">
          What do you need?
        </h1>

        {/* Communication Cards Grid */}
        <div className="grid grid-cols-2 gap-6">
          {needs.map((need) => (
            <button
              key={need.id}
              onClick={() => navigate(`/result/${need.id}`)}
              className={`aspect-square bg-gradient-to-br ${need.color} rounded-[2rem] shadow-xl hover:shadow-2xl transition-all duration-300 active:scale-95 hover:scale-105 flex flex-col items-center justify-center gap-5 p-8 relative overflow-hidden group`}
            >
              <div className="absolute inset-0 bg-white/0 group-hover:bg-white/10 transition-all duration-300"></div>
              <span className="text-8xl drop-shadow-lg relative z-10">{need.emoji}</span>
              <span className="text-2xl text-white tracking-tight relative z-10 font-medium drop-shadow-md">
                {need.label}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}