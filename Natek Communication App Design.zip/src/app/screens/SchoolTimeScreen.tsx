import { useNavigate } from 'react-router';
import { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Language, translations } from '../utils/translations';
import { CardWithAvatar } from '../components/CardWithAvatar';

export function SchoolTimeScreen() {
  const navigate = useNavigate();
  const [language, setLanguage] = useState<Language>('en');
  const [avatar, setAvatar] = useState<string>('boy1');

  useEffect(() => {
    const lang = localStorage.getItem('language') as Language;
    const savedAvatar = localStorage.getItem('avatar');
    if (lang) setLanguage(lang);
    if (savedAvatar) setAvatar(savedAvatar);
  }, []);

  const t = translations[language];
  const isRTL = language === 'ar';

  const needs = [
    { id: 'school', label: t.school, emoji: '🏫', color: 'from-blue-400 via-indigo-400 to-purple-400' },
    { id: 'book', label: t.book, emoji: '📚', color: 'from-cyan-400 via-sky-400 to-blue-400' },
    { id: 'help', label: t.help, emoji: '🙋', color: 'from-orange-400 via-amber-400 to-yellow-400' },
    { id: 'break', label: t.break, emoji: '⏸️', color: 'from-green-400 via-emerald-400 to-teal-400' },
    { id: 'toilet', label: t.toilet, emoji: '🚽', color: 'from-yellow-400 via-amber-400 to-orange-400' },
    { id: 'thirst', label: t.thirst, emoji: '💧', color: 'from-blue-400 via-cyan-400 to-sky-400' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-cyan-50 to-sky-100" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-md mx-auto min-h-screen bg-white/70 backdrop-blur-xl shadow-2xl px-10 py-12">
        {/* Back Button */}
        <button
          onClick={() => navigate('/routine')}
          className={`mb-10 flex items-center gap-3 px-5 py-3 bg-white/90 border-2 border-blue-200 rounded-full shadow-sm hover:shadow-md hover:border-blue-300 transition-all duration-300 active:scale-95 ${isRTL ? 'flex-row-reverse' : ''}`}
        >
          <ArrowLeft className={`w-6 h-6 text-blue-600 ${isRTL ? 'rotate-180' : ''}`} />
          <span className="text-lg text-blue-700">{t.back}</span>
        </button>

        {/* Title */}
        <div className="mb-12">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-gradient-to-br from-blue-400 to-cyan-500 rounded-2xl p-3 shadow-lg">
              <span className="text-4xl">🏫</span>
            </div>
            <h1 className={`text-4xl text-gray-900 tracking-tight ${isRTL ? 'text-right' : ''}`}>
              {t.schoolTime}
            </h1>
          </div>
          <p className={`text-xl text-blue-700 ${isRTL ? 'text-right' : ''}`}>{t.whatDoYouNeed}</p>
        </div>

        {/* Communication Cards Grid */}
        <div className="grid grid-cols-2 gap-5">
          {needs.map((need) => (
            <CardWithAvatar
              key={need.id}
              emoji={need.emoji}
              label={need.label}
              color={need.color}
              avatarKey={avatar}
              showAvatar={true}
              onClick={() => navigate(`/result/school/${need.id}`)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
