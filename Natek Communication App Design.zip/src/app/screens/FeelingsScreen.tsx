import { useNavigate } from 'react-router';
import { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Language, translations } from '../utils/translations';
import { CardWithAvatar } from '../components/CardWithAvatar';

export function FeelingsScreen() {
  const navigate = useNavigate();
  const [language, setLanguage] = useState<Language>('en');
  const [avatar, setAvatar] = useState<string>('boy1');

  useEffect(() => {
    const lang = localStorage.getItem('language') as Language;
    const savedAvatar = localStorage.getItem('avatar');
    if (lang) setLanguage(lang);
    if (savedAvatar) setAvatar(savedAvatar);
  }, []);

  const t = translations[language];
  const isRTL = language === 'ar';

  const feelings = [
    { id: 'happy', label: t.happy, emoji: '😊', color: 'from-yellow-400 via-amber-400 to-orange-400' },
    { id: 'sad', label: t.sad, emoji: '😢', color: 'from-blue-400 via-cyan-400 to-sky-400' },
    { id: 'angry', label: t.angry, emoji: '😠', color: 'from-red-400 via-rose-400 to-pink-400' },
    { id: 'scared', label: t.scared, emoji: '😨', color: 'from-purple-400 via-violet-400 to-indigo-400' },
    { id: 'excited', label: t.excited, emoji: '🤩', color: 'from-orange-400 via-amber-400 to-yellow-400' },
    { id: 'calm', label: t.calm, emoji: '😌', color: 'from-green-400 via-emerald-400 to-teal-400' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-fuchsia-50 to-pink-100" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-md mx-auto min-h-screen bg-white/70 backdrop-blur-xl shadow-2xl px-10 py-12">
        {/* Back Button */}
        <button
          onClick={() => navigate('/routine')}
          className={`mb-10 flex items-center gap-3 px-5 py-3 bg-white/90 border-2 border-purple-200 rounded-full shadow-sm hover:shadow-md hover:border-purple-300 transition-all duration-300 active:scale-95 ${isRTL ? 'flex-row-reverse' : ''}`}
        >
          <ArrowLeft className={`w-6 h-6 text-purple-600 ${isRTL ? 'rotate-180' : ''}`} />
          <span className="text-lg text-purple-700">{t.back}</span>
        </button>

        {/* Title */}
        <div className="mb-12">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-gradient-to-br from-purple-400 to-fuchsia-500 rounded-2xl p-3 shadow-lg">
              <span className="text-4xl">❤️</span>
            </div>
            <h1 className={`text-4xl text-gray-900 tracking-tight ${isRTL ? 'text-right' : ''}`}>
              {t.feelings}
            </h1>
          </div>
          <p className={`text-xl text-purple-700 ${isRTL ? 'text-right' : ''}`}>{t.howDoYouFeel}</p>
        </div>

        {/* Feelings Cards Grid */}
        <div className="grid grid-cols-2 gap-5">
          {feelings.map((feeling) => (
            <CardWithAvatar
              key={feeling.id}
              emoji={feeling.emoji}
              label={feeling.label}
              color={feeling.color}
              avatarKey={avatar}
              showAvatar={true}
              onClick={() => navigate(`/result/feelings/${feeling.id}`)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
