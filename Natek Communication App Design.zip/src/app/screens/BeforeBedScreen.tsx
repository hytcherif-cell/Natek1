import { useNavigate } from 'react-router';
import { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Language, translations } from '../utils/translations';
import { CardWithAvatar } from '../components/CardWithAvatar';

export function BeforeBedScreen() {
  const navigate = useNavigate();
  const [language, setLanguage] = useState<Language>('en');
  const [avatar, setAvatar] = useState<string>('boy1');

  useEffect(() => {
    const lang = localStorage.getItem('language') as Language;
    const savedAvatar = localStorage.getItem('avatar');
    if (lang) setLanguage(lang);
    if (savedAvatar) setAvatar(savedAvatar);
  }, []);

  const t = translations[language];
  const isRTL = language === 'ar';

  const needs = [
    { id: 'toilet', label: t.toilet, emoji: '🚽', color: 'from-purple-400 via-indigo-400 to-blue-400' },
    { id: 'water', label: t.water, emoji: '💧', color: 'from-blue-400 via-cyan-400 to-sky-400' },
    { id: 'sleep', label: t.sleep, emoji: '😴', color: 'from-indigo-400 via-violet-400 to-purple-400' },
    { id: 'tired', label: t.tired, emoji: '🥱', color: 'from-violet-400 via-purple-400 to-pink-400' },
    { id: 'brush', label: t.brush, emoji: '🪥', color: 'from-cyan-400 via-teal-400 to-blue-400' },
    { id: 'pajamas', label: t.pajamas, emoji: '👕', color: 'from-pink-400 via-rose-400 to-red-400' },
    { id: 'story', label: t.story, emoji: '📖', color: 'from-amber-400 via-yellow-400 to-orange-400' },
    { id: 'thirst', label: t.thirst, emoji: '🥤', color: 'from-sky-400 via-blue-400 to-indigo-400' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-800 to-blue-900" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-md mx-auto min-h-screen bg-indigo-950/40 backdrop-blur-xl shadow-2xl px-10 py-12">
        {/* Back Button */}
        <button
          onClick={() => navigate('/routine')}
          className={`mb-10 flex items-center gap-3 px-5 py-3 bg-white/10 border-2 border-indigo-400/30 rounded-full shadow-sm hover:shadow-md hover:border-indigo-300/50 transition-all duration-300 active:scale-95 backdrop-blur-md ${isRTL ? 'flex-row-reverse' : ''}`}
        >
          <ArrowLeft className={`w-6 h-6 text-indigo-200 ${isRTL ? 'rotate-180' : ''}`} />
          <span className="text-lg text-indigo-100">{t.back}</span>
        </button>

        {/* Title */}
        <div className="mb-12">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl p-3 shadow-lg ring-2 ring-purple-400/30">
              <span className="text-4xl">🌙</span>
            </div>
            <h1 className={`text-4xl text-white tracking-tight ${isRTL ? 'text-right' : ''}`}>
              {t.beforeBed}
            </h1>
          </div>
          <p className={`text-xl text-indigo-200 ${isRTL ? 'text-right' : ''}`}>{t.whatDoYouNeed}</p>
        </div>

        {/* Communication Cards Grid */}
        <div className="grid grid-cols-2 gap-5">
          {needs.map((need) => (
            <CardWithAvatar
              key={need.id}
              emoji={need.emoji}
              label={need.label}
              color={need.color}
              avatarKey={avatar}
              showAvatar={true}
              onClick={() => navigate(`/result/bed/${need.id}`)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}