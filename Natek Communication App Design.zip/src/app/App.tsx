import { BrowserRouter, Routes, Route, Navigate } from 'react-router';
import { SplashScreen } from './screens/SplashScreen';
import { LoginScreen } from './screens/LoginScreen';
import { HomeScreen } from './screens/HomeScreen';
import { RoutineScreen } from './screens/RoutineScreen';
import { BeforeGoingOutScreen } from './screens/BeforeGoingOutScreen';
import { BeforeBedScreen } from './screens/BeforeBedScreen';
import { MealTimeScreen } from './screens/MealTimeScreen';
import { PlayTimeScreen } from './screens/PlayTimeScreen';
import { SchoolTimeScreen } from './screens/SchoolTimeScreen';
import { FeelingsScreen } from './screens/FeelingsScreen';
import { PersonalizedScreen } from './screens/PersonalizedScreen';
import { ResultScreen } from './screens/ResultScreen';
import { AvatarSelectionModal } from './components/AvatarSelectionModal';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<SplashScreen />} />
        <Route path="/login" element={<LoginScreen />} />
        <Route path="/home" element={<HomeScreen />} />
        <Route path="/routine" element={<RoutineScreen />} />
        <Route path="/before-going-out" element={<BeforeGoingOutScreen />} />
        <Route path="/before-bed" element={<BeforeBedScreen />} />
        <Route path="/meal-time" element={<MealTimeScreen />} />
        <Route path="/play-time" element={<PlayTimeScreen />} />
        <Route path="/school-time" element={<SchoolTimeScreen />} />
        <Route path="/feelings" element={<FeelingsScreen />} />
        <Route path="/personalized" element={<PersonalizedScreen />} />
        <Route path="/result/:routine/:need" element={<ResultScreen />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
