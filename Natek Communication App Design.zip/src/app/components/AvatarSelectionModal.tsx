import { avatars, AvatarType } from '../utils/avatars';
import { Language, translations } from '../utils/translations';

interface AvatarSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (avatar: AvatarType) => void;
  currentAvatar: string;
  language: Language;
}

export function AvatarSelectionModal({ isOpen, onClose, onSelect, currentAvatar, language }: AvatarSelectionModalProps) {
  const t = translations[language];
  const isRTL = language === 'ar';

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6" onClick={onClose}>
      <div 
        className="bg-white rounded-[2rem] p-8 max-w-md w-full shadow-2xl"
        onClick={(e) => e.stopPropagation()}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        <h2 className={`text-3xl text-gray-900 mb-8 tracking-tight ${isRTL ? 'text-right' : ''}`}>
          {t.chooseAvatar}
        </h2>
        
        <div className="grid grid-cols-3 gap-4 mb-8">
          {Object.entries(avatars).map(([key, emoji]) => (
            <button
              key={key}
              onClick={() => {
                onSelect(key as AvatarType);
                onClose();
              }}
              className={`aspect-square rounded-3xl flex items-center justify-center text-6xl transition-all duration-300 hover:scale-110 active:scale-95 ${
                currentAvatar === key
                  ? 'bg-gradient-to-br from-blue-500 to-indigo-600 shadow-lg ring-4 ring-blue-200'
                  : 'bg-gray-100 hover:bg-gray-200 shadow-md'
              }`}
            >
              {emoji}
            </button>
          ))}
        </div>
        
        <button
          onClick={onClose}
          className="w-full py-5 bg-gray-100 text-gray-700 rounded-full text-xl font-medium hover:bg-gray-200 transition-all duration-300 active:scale-[0.98]"
        >
          {t.cancel}
        </button>
      </div>
    </div>
  );
}
