interface ProfileHeaderProps {
  name: string;
  age: number;
}

export function ProfileHeader({ name, age }: ProfileHeaderProps) {
  return (
    <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-3xl p-6 shadow-lg">
      <div className="flex items-center gap-5">
        {/* Avatar */}
        <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-md flex-shrink-0">
          <span className="text-5xl">👦</span>
        </div>
        
        {/* Name and Age */}
        <div>
          <h1 className="text-3xl text-white tracking-tight">
            {name}
          </h1>
          <p className="text-xl text-blue-100 mt-0.5">
            {age} years old
          </p>
        </div>
      </div>
    </div>
  );
}