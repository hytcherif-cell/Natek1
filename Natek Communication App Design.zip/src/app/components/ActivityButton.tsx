import { ReactNode } from 'react';

interface ActivityButtonProps {
  icon: ReactNode;
  label: string;
  bgColor: string;
  textColor: string;
  onClick?: () => void;
}

export function ActivityButton({ icon, label, bgColor, textColor, onClick }: ActivityButtonProps) {
  return (
    <button 
      onClick={onClick}
      className={`w-full ${bgColor} rounded-3xl px-7 py-8 shadow-lg hover:shadow-xl transition-all duration-300 active:scale-[0.98] hover:scale-[1.02]`}
    >
      <div className="flex items-center gap-5">
        {/* Icon container */}
        <div className="flex-shrink-0 bg-white/20 rounded-2xl p-4 backdrop-blur-sm">
          <div className={textColor}>
            {icon}
          </div>
        </div>
        
        {/* Label */}
        <span className={`text-2xl ${textColor} text-left flex-1 tracking-tight`}>
          {label}
        </span>
      </div>
    </button>
  );
}