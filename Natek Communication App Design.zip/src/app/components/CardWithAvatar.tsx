import { getAvatar } from '../utils/avatars';

interface CardWithAvatarProps {
  emoji: string;
  label: string;
  color: string;
  avatarKey?: string;
  onClick: () => void;
  showAvatar?: boolean;
}

export function CardWithAvatar({ emoji, label, color, avatarKey, onClick, showAvatar = false }: CardWithAvatarProps) {
  return (
    <button
      onClick={onClick}
      className={`aspect-square bg-gradient-to-br ${color} rounded-[2rem] shadow-xl hover:shadow-2xl transition-all duration-300 active:scale-95 hover:scale-105 flex flex-col items-center justify-center gap-3 p-6 relative overflow-hidden group`}
    >
      <div className="absolute inset-0 bg-white/0 group-hover:bg-white/10 transition-all duration-300"></div>
      
      {showAvatar && avatarKey && (
        <div className="absolute top-3 right-3 w-12 h-12 bg-white/90 rounded-full flex items-center justify-center shadow-md z-10">
          <span className="text-2xl">{getAvatar(avatarKey)}</span>
        </div>
      )}
      
      <span className="text-7xl drop-shadow-lg relative z-10">{emoji}</span>
      <span className="text-xl text-white tracking-tight relative z-10 font-medium drop-shadow-md text-center leading-tight">
        {label}
      </span>
    </button>
  );
}
