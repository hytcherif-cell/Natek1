interface NeedCardProps {
  emoji: string;
  label: string;
  color: string;
}

export function NeedCard({ emoji, label, color }: NeedCardProps) {
  return (
    <button className={`aspect-square bg-gradient-to-br ${color} rounded-3xl shadow-md hover:shadow-lg transition-all duration-300 active:scale-95 hover:scale-105 flex flex-col items-center justify-center gap-3 p-6`}>
      <span className="text-6xl drop-shadow-sm">{emoji}</span>
      <span className="text-lg text-white tracking-tight">{label}</span>
    </button>
  );
}
